import { useState } from "react";

export default function App() {
  const [activeSection, setActiveSection] = useState<string>("checkin");

  const sections = [
    { id: "checkin", title: "Check-in & Check-out", icon: "📋" },
    { id: "guests", title: "Kebijakan Tamu & Anak-anak", icon: "👥" },
    { id: "cancellation", title: "Pembatalan & Pembayaran", icon: "💳" },
    { id: "facilities", title: "Aturan & Fasilitas", icon: "🏡" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-stone-100">
      {/* Header */}
      <header className="bg-gradient-to-r from-amber-800 to-stone-800 text-white shadow-lg">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center text-3xl">
                🏠
              </div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">Woodstone Homestay</h1>
                <p className="text-amber-200 text-sm">Terms of Service</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-amber-100 text-sm">Selamat Datang</p>
              <p className="text-amber-200 text-xs">Baca dengan teliti sebelum memesan</p>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white shadow-md sticky top-0 z-10">
        <div className="container mx-auto px-4">
          <div className="flex overflow-x-auto gap-2 py-3 scrollbar-hide">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
                  activeSection === section.id
                    ? "bg-amber-600 text-white shadow-md"
                    : "bg-stone-100 text-stone-700 hover:bg-stone-200"
                }`}
              >
                <span>{section.icon}</span>
                <span className="font-medium text-sm">{section.title}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Check-in & Check-out Section */}
          {activeSection === "checkin" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-amber-600">
                <h2 className="text-2xl font-bold text-stone-800 mb-4 flex items-center gap-3">
                  <span>📋</span> Aturan Check-in & Check-out
                </h2>
                
                <div className="space-y-4">
                  <div className="flex items-start gap-4 p-4 bg-amber-50 rounded-xl">
                    <div className="w-12 h-12 bg-amber-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Waktu Check-in</h3>
                      <p className="text-stone-600">Mulai pukul <span className="font-bold text-amber-700">14:00 hingga 22:00</span></p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-stone-50 rounded-xl">
                    <div className="w-12 h-12 bg-stone-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Waktu Check-out</h3>
                      <p className="text-stone-600">Mulai pukul <span className="font-bold text-stone-700">07:00 hingga 12:00</span></p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-xl">
                    <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Persyaratan Identitas</h3>
                      <p className="text-stone-600">Tamu wajib menunjukkan <span className="font-semibold text-blue-700">kartu identitas berfoto (KTP/Passport)</span> yang sah dan <span className="font-semibold text-blue-700">kartu kredit</span> saat proses check-in.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-green-50 rounded-xl">
                    <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Pemberitahuan Kedatangan</h3>
                      <p className="text-stone-600">Tamu diharapkan menginformasikan <span className="font-semibold text-green-700">perkiraan waktu kedatangan</span> terlebih dahulu kepada pihak pengelola.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Guests & Children Section */}
          {activeSection === "guests" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-red-600">
                <h2 className="text-2xl font-bold text-stone-800 mb-4 flex items-center gap-3">
                  <span>👥</span> Kebijakan Tamu & Anak-anak
                </h2>
                
                <div className="space-y-4">
                  <div className="flex items-start gap-4 p-4 bg-red-50 rounded-xl border border-red-200">
                    <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Batasan Usia</h3>
                      <p className="text-stone-600">Akomodasi ini ditujukan <span className="font-bold text-red-700">khusus dewasa (adults-only)</span>. <span className="font-bold text-red-700">Anak-anak tidak diperbolehkan</span> menginap di properti ini.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-orange-50 rounded-xl border border-orange-200">
                    <div className="w-12 h-12 bg-orange-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M12 5l7 7-7 7" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Tempat Tidur Tambahan</h3>
                      <p className="text-stone-600"><span className="font-bold text-orange-700">Tidak tersedia</span> fasilitas ranjang bayi (cot) maupun tempat tidur tambahan (extra bed).</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-purple-50 rounded-xl border border-purple-200">
                    <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Pendampingan</h3>
                      <p className="text-stone-600">Tamu di bawah usia <span className="font-bold text-purple-700">18 tahun</span> hanya bisa check-in jika <span className="font-bold text-purple-700">didampingi orang tua atau wali resmi</span>.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Cancellation & Payment Section */}
          {activeSection === "cancellation" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-indigo-600">
                <h2 className="text-2xl font-bold text-stone-800 mb-4 flex items-center gap-3">
                  <span>💳</span> Pembatalan & Pembayaran
                </h2>
                
                <div className="flex items-start gap-4 p-6 bg-indigo-50 rounded-xl">
                  <div className="w-12 h-12 bg-indigo-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold text-stone-800 mb-2">Kebijakan Pembatalan & Pembayaran</h3>
                    <p className="text-stone-600 mb-3">Kebijakan pembatalan dan pembayaran di muka (prepayment) <span className="font-semibold text-indigo-700">bervariasi</span> tergantung pada:</p>
                    <ul className="list-disc list-inside space-y-1 text-stone-600 ml-2">
                      <li>Tipe kamar yang dipilih</li>
                      <li>Opsi harga yang dipilih saat pemesanan</li>
                    </ul>
                  </div>
                </div>

                <div className="mt-4 p-4 bg-yellow-50 rounded-xl border border-yellow-200">
                  <div className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p className="text-stone-700 text-sm">
                      <span className="font-semibold">Penting:</span> Silakan periksa detail kebijakan pembatalan dan pembayaran pada halaman pemesanan Anda sebelum mengkonfirmasi reservasi.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Rules & Facilities Section */}
          {activeSection === "facilities" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-teal-600">
                <h2 className="text-2xl font-bold text-stone-800 mb-4 flex items-center gap-3">
                  <span>🏡</span> Aturan Tambahan & Fasilitas
                </h2>
                
                <div className="space-y-4">
                  <div className="flex items-start gap-4 p-4 bg-teal-50 rounded-xl">
                    <div className="w-12 h-12 bg-teal-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Permintaan Khusus</h3>
                      <p className="text-stone-600">Semua permintaan khusus bersifat <span className="font-semibold text-teal-700">tergantung ketersediaan</span> dan mungkin <span className="font-semibold text-teal-700">dikenakan biaya tambahan</span>.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-emerald-50 rounded-xl">
                    <div className="w-12 h-12 bg-emerald-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-2">Fasilitas Umum</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center gap-2 text-stone-600">
                          <svg className="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                          Dapur bersama
                        </li>
                        <li className="flex items-center gap-2 text-stone-600">
                          <svg className="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                          WiFi gratis di seluruh area
                        </li>
                        <li className="flex items-center gap-2 text-stone-600">
                          <svg className="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                          Taman
                        </li>
                        <li className="flex items-center gap-2 text-stone-600">
                          <svg className="w-4 h-4 text-emerald-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                          Lounge bersama
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-cyan-50 rounded-xl">
                    <div className="w-12 h-12 bg-cyan-600 rounded-lg flex items-center justify-center text-white flex-shrink-0">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-stone-800 mb-1">Layanan Tambahan</h3>
                      <p className="text-stone-600">Pihak homestay menyediakan <span className="font-semibold text-cyan-700">penyewaan sepeda motor dan sepeda</span> berdasarkan ulasan tamu di Tripadvisor.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Footer */}
          <footer className="mt-8 text-center">
            <div className="bg-gradient-to-r from-amber-800 to-stone-800 rounded-2xl p-6 text-white shadow-lg">
              <p className="text-lg font-semibold mb-2">Woodstone Homestay</p>
              <p className="text-amber-200 text-sm">Terima kasih telah membaca Terms of Service kami</p>
              <p className="text-amber-300 text-xs mt-2">Diperbarui: 2026</p>
            </div>
          </footer>
        </div>
      </main>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
